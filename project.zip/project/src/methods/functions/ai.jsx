import {postRequestToAi} from "../APIs/ai.jsx";

export const sendPostToAi = async (object) => {
    return await postRequestToAi(object);
}